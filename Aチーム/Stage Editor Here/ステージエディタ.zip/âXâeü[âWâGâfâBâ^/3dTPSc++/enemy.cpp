//===============================================
//
// �t�B�[���h���� (block.cpp)
// Author : ��{��
//
//===============================================

//========================
// �C���N���[�h�t�@�C��
//========================
#include "enemy.h"

#include "manager.h"
#include "renderer.h"

//========================================
// �ÓI�����o�ϐ��錾
//========================================
LPD3DXMESH CEnemy::m_apMesh[CEnemy::TYPE_MAX] = {};
LPD3DXBUFFER CEnemy::m_apBuffMat[CEnemy::TYPE_MAX] = {};
DWORD CEnemy::m_aNumMat[CEnemy::TYPE_MAX] = {};
LPDIRECT3DTEXTURE9 CEnemy::m_apTexture[CEnemy::TYPE_MAX] = {};

CEnemy* CEnemy::m_pSelectEnemy = NULL;
int CEnemy::m_nNumAll = 0;

//=============================================================================
// �R���X�g���N�^
//=============================================================================
CEnemy::CEnemy()
	: CScene3D(CScene::OBJTYPE_ENEMY)
{
	m_collisionSize = DEFAULT_VECTOR;
	m_nType = TYPE_WHITE_ANT;
	m_bWallRun = false;

	m_bBlink = false;
	m_nCntTime = 0;
	m_nNumber = m_nNumAll;

	m_nNumAll++;
}

//=============================================================================
// �f�X�g���N�^
//=============================================================================
CEnemy::~CEnemy()
{
	m_nNumAll--;
}

//=============================================================================
// ����������
//=============================================================================
HRESULT CEnemy::Init(D3DXVECTOR3 pos, D3DXVECTOR3 size, D3DXVECTOR3 rot, int nType)
{
	CScene3D::Init(pos, size, rot);

	SetScale(size);

	// ���b�V���A�e�N�X�`�����o�C���h
	BindMesh(m_apMesh[m_nType], m_apBuffMat[m_nType], m_aNumMat[m_nType]);
	BindTexture(m_apTexture[m_nType]);

	return S_OK;
}

//=============================================================================
// �I������
//=============================================================================
void CEnemy::Uninit(void)
{
	CScene3D::Uninit();
}

//=============================================================================
// �X�V����
//=============================================================================
void CEnemy::Update(void)
{
	// 0���傫���Ȃ�A���炷
	if (m_nCntTime > 0) {
		m_nCntTime--;
	}

	// �I�����Ă���u���b�N��_�ł�����
	if (this == m_pSelectEnemy) {
		if (m_nCntTime == 0) {
			m_bBlink = !m_bBlink;

			m_nCntTime = BLINK_TIME;
		}
	}
	else {
		m_nCntTime = 0;

		m_bBlink = false;
	}

	CScene3D::Update();
}

//=============================================================================
// �`�揈��
//=============================================================================
void CEnemy::Draw(void)
{
	LPDIRECT3DDEVICE9 pDevice = CManager::GetRenderer()->GetDevice();

	if (m_bBlink == false) {
		CScene3D::Draw();
	}
}

//=============================================================================
// ���f���f�[�^�ǂݍ��ݏ���
//=============================================================================
HRESULT CEnemy::Load(void)
{
	LPDIRECT3DDEVICE9 pDevice = CManager::GetRenderer()->GetDevice();

	//==============================
	// ���A��
	//==============================
	// ���f��
	D3DXLoadMeshFromX(LPCSTR("data/MODEL/enemy/ant000.x"), D3DXMESH_SYSTEMMEM, pDevice, NULL,
		&m_apBuffMat[TYPE_WHITE_ANT], NULL, &m_aNumMat[TYPE_WHITE_ANT], &m_apMesh[TYPE_WHITE_ANT]);

	//==============================
	// ���A��
	//==============================
	// ���f��
	D3DXLoadMeshFromX(LPCSTR("data/MODEL/enemy/ant000.x"), D3DXMESH_SYSTEMMEM, pDevice, NULL,
		&m_apBuffMat[TYPE_BLACK_ANT], NULL, &m_aNumMat[TYPE_BLACK_ANT], &m_apMesh[TYPE_BLACK_ANT]);

	//==============================
	// ���O��
	//==============================
	// ���f��
	D3DXLoadMeshFromX(LPCSTR("data/MODEL/enemy/spider000.x"), D3DXMESH_SYSTEMMEM, pDevice, NULL,
		&m_apBuffMat[TYPE_YELLOW_SPIDER], NULL, &m_aNumMat[TYPE_YELLOW_SPIDER], &m_apMesh[TYPE_YELLOW_SPIDER]);

	//==============================
	// ���O��
	//==============================
	// ���f��
	D3DXLoadMeshFromX(LPCSTR("data/MODEL/enemy/spider000.x"), D3DXMESH_SYSTEMMEM, pDevice, NULL,
		&m_apBuffMat[TYPE_BLACK_SPIDER], NULL, &m_aNumMat[TYPE_BLACK_SPIDER], &m_apMesh[TYPE_BLACK_SPIDER]);

	//==============================
	// UFO
	//==============================
	// ���f��
	D3DXLoadMeshFromX(LPCSTR("data/MODEL/enemy/UFO.x"), D3DXMESH_SYSTEMMEM, pDevice, NULL,
		&m_apBuffMat[TYPE_UFO], NULL, &m_aNumMat[TYPE_UFO], &m_apMesh[TYPE_UFO]);

	return S_OK;
}

//=============================================================================
// ���f���f�[�^�j������
//=============================================================================
void CEnemy::Unload(void)
{
	for (int nCnt = 0; nCnt < CEnemy::TYPE_MAX; nCnt++) {
		if (m_apMesh[nCnt] != NULL) {
			m_apMesh[nCnt]->Release();
			m_apMesh[nCnt] = NULL;
		}
		if (m_apBuffMat[nCnt] != NULL) {
			m_apBuffMat[nCnt]->Release();
			m_apBuffMat[nCnt] = NULL;
		}
		if (m_apTexture[nCnt] != NULL) {
			m_apTexture[nCnt]->Release();
			m_apTexture[nCnt] = NULL;
		}
	}
}

//=============================================================================
// �C���X�^���X��������
//=============================================================================
CEnemy* CEnemy::Create(D3DXVECTOR3 pos, D3DXVECTOR3 rot, int nType)
{
	CEnemy* pEnemy = NULL;
	pEnemy = new CEnemy;
	pEnemy->m_nType = nType;
	pEnemy->Init(pos, D3DXVECTOR3(1.0f, 1.0f, 1.0f), rot, nType);

	if (nType == TYPE_BLACK_ANT || nType == TYPE_BLACK_SPIDER)
	{
		pEnemy->SetScale(D3DXVECTOR3(2.0f, 2.0f, 2.0f));
	}

	pEnemy->m_collisionSize = ENEMY_COLLISION_SIZE;

	return pEnemy;
}
