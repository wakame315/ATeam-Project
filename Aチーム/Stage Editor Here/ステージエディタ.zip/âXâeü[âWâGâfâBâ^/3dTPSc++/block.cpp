//===============================================
//
// �t�B�[���h���� (block.cpp)
// Author : ��{��
//
//===============================================

//========================
// �C���N���[�h�t�@�C��
//========================
#include "block.h"

#include "manager.h"
#include "renderer.h"

//========================================
// �ÓI�����o�ϐ��錾
//========================================
LPD3DXMESH CBlock::m_apMesh[CBlock::TYPE_MAX]            = {};
LPD3DXBUFFER CBlock::m_apBuffMat[CBlock::TYPE_MAX]       = {};
DWORD CBlock::m_aNumMat[CBlock::TYPE_MAX]                = {};
LPDIRECT3DTEXTURE9 CBlock::m_apTexture[CBlock::TYPE_MAX] = {};

CBlock* CBlock::m_pSelectBlock = NULL;
int CBlock::m_nNumAll          = 0;

//=============================================================================
// �R���X�g���N�^
//=============================================================================
CBlock::CBlock()
  : CScene3D(CScene::OBJTYPE_BLOCK)
{
    m_collisionSize = DEFAULT_VECTOR;
    m_nType         = TYPE_BUILDING001;
    m_bWallRun      = false;

    m_bBlink   = false;
    m_nCntTime = 0;
    m_nNumber  = m_nNumAll;

    m_nNumAll++;
}

//=============================================================================
// �f�X�g���N�^
//=============================================================================
CBlock::~CBlock()
{
    m_nNumAll--;
}

//=============================================================================
// ����������
//=============================================================================
HRESULT CBlock::Init(D3DXVECTOR3 pos, D3DXVECTOR3 size, D3DXVECTOR3 rot, int nType)
{
    CScene3D::Init(pos, size, rot);

    SetScale(size);

    // ���b�V���A�e�N�X�`�����o�C���h
    BindMesh(m_apMesh[m_nType], m_apBuffMat[m_nType], m_aNumMat[m_nType]);
    BindTexture(m_apTexture[m_nType]);

    return S_OK;
}

//=============================================================================
// �I������
//=============================================================================
void CBlock::Uninit(void)
{
    CScene3D::Uninit();
}

//=============================================================================
// �X�V����
//=============================================================================
void CBlock::Update(void)
{
    // 0���傫���Ȃ�A���炷
    if(m_nCntTime > 0) {
        m_nCntTime--;
    }

    // �I�����Ă���u���b�N��_�ł�����
    if(this == m_pSelectBlock) {
        if(m_nCntTime == 0) {
            m_bBlink = !m_bBlink;

            m_nCntTime = BLINK_TIME;
        }
    }
    else {
        m_nCntTime = 0;

        m_bBlink = false;
    }

    CScene3D::Update();
}

//=============================================================================
// �`�揈��
//=============================================================================
void CBlock::Draw(void)
{
    LPDIRECT3DDEVICE9 pDevice = CManager::GetRenderer()->GetDevice();

    if(m_bBlink == false) {
        CScene3D::Draw();
    }
}

//=============================================================================
// ���f���f�[�^�ǂݍ��ݏ���
//=============================================================================
HRESULT CBlock::Load(void)
{
    LPDIRECT3DDEVICE9 pDevice = CManager::GetRenderer()->GetDevice();

    //==============================
    // �r��001
    //==============================
    // ���f��
    D3DXLoadMeshFromX(LPCSTR("data/MODEL/building/building001.x"), D3DXMESH_SYSTEMMEM, pDevice, NULL,
                      &m_apBuffMat[TYPE_BUILDING001], NULL, &m_aNumMat[TYPE_BUILDING001], &m_apMesh[TYPE_BUILDING001]);
    // �e�N�X�`��
    D3DXCreateTextureFromFile(pDevice, "data/TEXTURE/building001.jpg", &m_apTexture[TYPE_BUILDING001]);

    //==============================
    // �r��101
    //==============================
    // ���f��
    D3DXLoadMeshFromX(LPCSTR("data/MODEL/building/building101.x"), D3DXMESH_SYSTEMMEM, pDevice, NULL,
                      &m_apBuffMat[TYPE_BUILDING101], NULL, &m_aNumMat[TYPE_BUILDING101], &m_apMesh[TYPE_BUILDING101]);
    // �e�N�X�`��
    D3DXCreateTextureFromFile(pDevice, "data/TEXTURE/building101.jpg", &m_apTexture[TYPE_BUILDING101]);

    //==============================
    // �r��201
    //==============================
    // ���f��
    D3DXLoadMeshFromX(LPCSTR("data/MODEL/building/building201.x"), D3DXMESH_SYSTEMMEM, pDevice, NULL,
                      &m_apBuffMat[TYPE_BUILDING201], NULL, &m_aNumMat[TYPE_BUILDING201], &m_apMesh[TYPE_BUILDING201]);
    // �e�N�X�`��
    D3DXCreateTextureFromFile(pDevice, "data/TEXTURE/building201.jpg", &m_apTexture[TYPE_BUILDING201]);

    //==============================
    // �r��301
    //==============================
    // ���f��
    D3DXLoadMeshFromX(LPCSTR("data/MODEL/building/building301.x"), D3DXMESH_SYSTEMMEM, pDevice, NULL,
                      &m_apBuffMat[TYPE_BUILDING301], NULL, &m_aNumMat[TYPE_BUILDING301], &m_apMesh[TYPE_BUILDING301]);
    // �e�N�X�`��
    D3DXCreateTextureFromFile(pDevice, "data/TEXTURE/building301.jpg", &m_apTexture[TYPE_BUILDING301]);

    //==============================
    // �r��401
    //==============================
    // ���f��
    D3DXLoadMeshFromX(LPCSTR("data/MODEL/building/building401.x"), D3DXMESH_SYSTEMMEM, pDevice, NULL,
                      &m_apBuffMat[TYPE_BUILDING401], NULL, &m_aNumMat[TYPE_BUILDING401], &m_apMesh[TYPE_BUILDING401]);
    // �e�N�X�`��
    D3DXCreateTextureFromFile(pDevice, "data/TEXTURE/building401.jpg", &m_apTexture[TYPE_BUILDING401]);

    //==============================
    // �r��501
    //==============================
    // ���f��
    D3DXLoadMeshFromX(LPCSTR("data/MODEL/building/building501.x"), D3DXMESH_SYSTEMMEM, pDevice, NULL,
                      &m_apBuffMat[TYPE_BUILDING501], NULL, &m_aNumMat[TYPE_BUILDING501], &m_apMesh[TYPE_BUILDING501]);
    // �e�N�X�`��
    D3DXCreateTextureFromFile(pDevice, "data/TEXTURE/building501.jpg", &m_apTexture[TYPE_BUILDING501]);

    //==============================
    // �M���@
    //==============================
    // ���f��
    D3DXLoadMeshFromX(LPCSTR("data/MODEL/object/Signal.x"), D3DXMESH_SYSTEMMEM, pDevice, NULL,
                      &m_apBuffMat[TYPE_SIGNAL], NULL, &m_aNumMat[TYPE_SIGNAL], &m_apMesh[TYPE_SIGNAL]);

    //==============================
    // �X��
    //==============================
    // ���f��
    D3DXLoadMeshFromX(LPCSTR("data/MODEL/object/light.x"), D3DXMESH_SYSTEMMEM, pDevice, NULL,
                      &m_apBuffMat[TYPE_LIGHT], NULL, &m_aNumMat[TYPE_LIGHT], &m_apMesh[TYPE_LIGHT]);

    //==============================
    // �S�~��
    //==============================
    // ���f��
    D3DXLoadMeshFromX(LPCSTR("data/MODEL/object/DustBox.x"), D3DXMESH_SYSTEMMEM, pDevice, NULL,
                      &m_apBuffMat[TYPE_DUSTBOX], NULL, &m_aNumMat[TYPE_DUSTBOX], &m_apMesh[TYPE_DUSTBOX]);

    //==============================
    // �X��2
    //==============================
    // ���f��
    D3DXLoadMeshFromX(LPCSTR("data/MODEL/object/light2.x"), D3DXMESH_SYSTEMMEM, pDevice, NULL,
                      &m_apBuffMat[TYPE_LIGHT2], NULL, &m_aNumMat[TYPE_LIGHT2], &m_apMesh[TYPE_LIGHT2]);

    //==============================
    // ��1
    //==============================
    // ���f��
    D3DXLoadMeshFromX(LPCSTR("data/MODEL/object/wood1.x"), D3DXMESH_SYSTEMMEM, pDevice, NULL,
                      &m_apBuffMat[TYPE_WOOD1], NULL, &m_aNumMat[TYPE_WOOD1], &m_apMesh[TYPE_WOOD1]);

    //==============================
    // ��2
    //==============================
    // ���f��
    D3DXLoadMeshFromX(LPCSTR("data/MODEL/object/wood2.x"), D3DXMESH_SYSTEMMEM, pDevice, NULL,
                      &m_apBuffMat[TYPE_WOOD2], NULL, &m_aNumMat[TYPE_WOOD2], &m_apMesh[TYPE_WOOD2]);

    //==============================
    // ��3
    //==============================
    // ���f��
    D3DXLoadMeshFromX(LPCSTR("data/MODEL/object/wood3.x"), D3DXMESH_SYSTEMMEM, pDevice, NULL,
                      &m_apBuffMat[TYPE_WOOD3], NULL, &m_aNumMat[TYPE_WOOD3], &m_apMesh[TYPE_WOOD3]);
    // �e�N�X�`��
    D3DXCreateTextureFromFile(pDevice, "data/TEXTURE/ki.jpg", &m_apTexture[TYPE_WOOD3]);

    //==============================
    // �x���`
    //==============================
    // ���f��
    D3DXLoadMeshFromX(LPCSTR("data/MODEL/object/bench.x"), D3DXMESH_SYSTEMMEM, pDevice, NULL,
                      &m_apBuffMat[TYPE_BENCH], NULL, &m_aNumMat[TYPE_BENCH], &m_apMesh[TYPE_BENCH]);

    //==============================
    // ��
    //==============================
    // ���f��
    D3DXLoadMeshFromX(LPCSTR("data/MODEL/object/tukue.x"), D3DXMESH_SYSTEMMEM, pDevice, NULL,
                      &m_apBuffMat[TYPE_TUKUE], NULL, &m_aNumMat[TYPE_TUKUE], &m_apMesh[TYPE_TUKUE]);

    //==============================
    // �K�[�h���[��
    //==============================
    // ���f��
    D3DXLoadMeshFromX(LPCSTR("data/MODEL/object/guardrail.x"), D3DXMESH_SYSTEMMEM, pDevice, NULL,
                      &m_apBuffMat[TYPE_GUARDRAIL], NULL, &m_aNumMat[TYPE_GUARDRAIL], &m_apMesh[TYPE_GUARDRAIL]);

	//==============================
	// �W�����O���W��
	//==============================
	// ���f��
	D3DXLoadMeshFromX(LPCSTR("data/MODEL/object/playground.x"), D3DXMESH_SYSTEMMEM, pDevice, NULL,
		&m_apBuffMat[TYPE_PLAYGROUND], NULL, &m_aNumMat[TYPE_PLAYGROUND], &m_apMesh[TYPE_PLAYGROUND]);

	//==============================
	// ���ӃT�C��
	//==============================
	// ���f��
	D3DXLoadMeshFromX(LPCSTR("data/MODEL/object/signEmar.x"), D3DXMESH_SYSTEMMEM, pDevice, NULL,
		&m_apBuffMat[TYPE_SIGN_EMAR], NULL, &m_aNumMat[TYPE_SIGN_EMAR], &m_apMesh[TYPE_SIGN_EMAR]);

	//==============================
	// �\���H�T�C��
	//==============================
	// ���f��
	D3DXLoadMeshFromX(LPCSTR("data/MODEL/object/signInter.x"), D3DXMESH_SYSTEMMEM, pDevice, NULL,
		&m_apBuffMat[TYPE_SIGN_INTER], NULL, &m_aNumMat[TYPE_SIGN_INTER], &m_apMesh[TYPE_SIGN_INTER]);

	//==============================
	// ���ԋ֎~�T�C��
	//==============================
	// ���f��
	D3DXLoadMeshFromX(LPCSTR("data/MODEL/object/signNoPark.x"), D3DXMESH_SYSTEMMEM, pDevice, NULL,
		&m_apBuffMat[TYPE_SIGN_NO_PARK], NULL, &m_aNumMat[TYPE_SIGN_NO_PARK], &m_apMesh[TYPE_SIGN_NO_PARK]);

	//==============================
	// ��
	//==============================
	// ���f��
	D3DXLoadMeshFromX(LPCSTR("data/MODEL/object/car.x"), D3DXMESH_SYSTEMMEM, pDevice, NULL,
		&m_apBuffMat[TYPE_CAR], NULL, &m_aNumMat[TYPE_CAR], &m_apMesh[TYPE_CAR]);

	//==============================
	// �R���r�j
	//==============================
	// ���f��
	D3DXLoadMeshFromX(LPCSTR("data/MODEL/object/convini.x"), D3DXMESH_SYSTEMMEM, pDevice, NULL,
		&m_apBuffMat[TYPE_CONVINI], NULL, &m_aNumMat[TYPE_CONVINI], &m_apMesh[TYPE_CONVINI]);

	//==============================
	// �R���e�i
	//==============================
	// ���f��
	D3DXLoadMeshFromX(LPCSTR("data/MODEL/object/container.x"), D3DXMESH_SYSTEMMEM, pDevice, NULL,
		&m_apBuffMat[TYPE_CONTAINER], NULL, &m_aNumMat[TYPE_CONTAINER], &m_apMesh[TYPE_CONTAINER]);

	//==============================
	// �K�X�^���N
	//==============================
	// ���f��
	D3DXLoadMeshFromX(LPCSTR("data/MODEL/object/gas.x"), D3DXMESH_SYSTEMMEM, pDevice, NULL,
		&m_apBuffMat[TYPE_GAS], NULL, &m_aNumMat[TYPE_GAS], &m_apMesh[TYPE_GAS]);

	//==============================
	// �q��
	//==============================
	// ���f��
	D3DXLoadMeshFromX(LPCSTR("data/MODEL/object/souko.x"), D3DXMESH_SYSTEMMEM, pDevice, NULL,
		&m_apBuffMat[TYPE_SOUKO], NULL, &m_aNumMat[TYPE_SOUKO], &m_apMesh[TYPE_SOUKO]);

	//==============================
	// �S��
	//==============================
	// ���f��
	D3DXLoadMeshFromX(LPCSTR("data/MODEL/object/metal.x"), D3DXMESH_SYSTEMMEM, pDevice, NULL,
		&m_apBuffMat[TYPE_METAL], NULL, &m_aNumMat[TYPE_METAL], &m_apMesh[TYPE_METAL]);

	//==============================
	// �\�[���[�p�l��
	//==============================
	// ���f��
	D3DXLoadMeshFromX(LPCSTR("data/MODEL/object/solar.x"), D3DXMESH_SYSTEMMEM, pDevice, NULL,
		&m_apBuffMat[TYPE_SOLAR], NULL, &m_aNumMat[TYPE_SOLAR], &m_apMesh[TYPE_SOLAR]);
	// �e�N�X�`��
	D3DXCreateTextureFromFile(pDevice, "data/TEXTURE/SolarPanel.jpg", &m_apTexture[TYPE_SOLAR]);

	//==============================
	// �^���[
	//==============================
	// ���f��
	D3DXLoadMeshFromX(LPCSTR("data/MODEL/object/tower.x"), D3DXMESH_SYSTEMMEM, pDevice, NULL,
		&m_apBuffMat[TYPE_TOWER], NULL, &m_aNumMat[TYPE_TOWER], &m_apMesh[TYPE_TOWER]);

	//==============================
	// �N���X�^��
	//==============================
	// ���f��
	D3DXLoadMeshFromX(LPCSTR("data/MODEL/object/crystal.x"), D3DXMESH_SYSTEMMEM, pDevice, NULL,
		&m_apBuffMat[TYPE_CRYSTAL], NULL, &m_aNumMat[TYPE_CRYSTAL], &m_apMesh[TYPE_CRYSTAL]);

    return S_OK;
}

//=============================================================================
// ���f���f�[�^�j������
//=============================================================================
void CBlock::Unload(void)
{
    for(int nCnt = 0; nCnt < CBlock::TYPE_MAX; nCnt++) {
        if(m_apMesh[nCnt] != NULL) {
            m_apMesh[nCnt]->Release();
            m_apMesh[nCnt] = NULL;
        }
        if(m_apBuffMat[nCnt] != NULL) {
            m_apBuffMat[nCnt]->Release();
            m_apBuffMat[nCnt] = NULL;
        }
        if(m_apTexture[nCnt] != NULL) {
            m_apTexture[nCnt]->Release();
            m_apTexture[nCnt] = NULL;
        }
    }
}

//=============================================================================
// �C���X�^���X��������
//=============================================================================
CBlock* CBlock::Create(D3DXVECTOR3 pos, D3DXVECTOR3 rot, int nType)
{
    CBlock* pBlock  = NULL;
    pBlock          = new CBlock;
    pBlock->m_nType = nType;
    pBlock->Init(pos, D3DXVECTOR3(1.0f, 1.0f, 1.0f), rot, nType);

    // ��ނ��ƂɁA���т���l��ς���
    switch((OBJTYPE)nType) {
        case TYPE_BUILDING001:

            pBlock->m_collisionSize = BLOCK_BUILDING_COLLISION_SIZE;
            pBlock->m_bWallRun      = true;

            break;

        case TYPE_BUILDING101:

            pBlock->m_collisionSize = BLOCK_BUILDING_COLLISION_SIZE;
            pBlock->m_bWallRun      = true;

            break;

        case TYPE_BUILDING201:

            pBlock->m_collisionSize = BLOCK_BUILDING_COLLISION_SIZE;
            pBlock->m_bWallRun      = true;

            break;

        case TYPE_BUILDING301:

            pBlock->m_collisionSize = BLOCK_BUILDING_COLLISION_SIZE;
            pBlock->m_bWallRun      = true;

            break;

        case TYPE_BUILDING401:

            pBlock->m_collisionSize = BLOCK_BUILDING_COLLISION_SIZE;
            pBlock->m_bWallRun      = true;

            break;

        case TYPE_BUILDING501:

            pBlock->m_collisionSize = BLOCK_BUILDING_COLLISION_SIZE;
            pBlock->m_bWallRun      = true;

            break;

        case TYPE_SIGNAL:

            pBlock->m_collisionSize = BLOCK_SIGNAL_COLLISION_SIZE;
            pBlock->m_bWallRun      = true;

            break;

        case TYPE_LIGHT:

            pBlock->m_collisionSize = BLOCK_LIGHT_COLLISION_SIZE;
            pBlock->m_bWallRun      = true;

            break;

        case TYPE_DUSTBOX:

            pBlock->m_collisionSize = BLOCK_DUSTBOX_COLLISION_SIZE;

            break;

        case TYPE_LIGHT2:

            pBlock->m_collisionSize = BLOCK_SIGNAL_COLLISION_SIZE;
            pBlock->m_bWallRun      = true;

            break;

        case TYPE_WOOD1:

            pBlock->m_collisionSize = BLOCK_WOOD_COLLISION_SIZE;
            pBlock->m_bWallRun      = true;

            break;

        case TYPE_WOOD2:

            pBlock->m_collisionSize = BLOCK_WOOD2_COLLISION_SIZE;
            pBlock->m_bWallRun      = true;

            break;

        case TYPE_WOOD3:

            pBlock->m_collisionSize = BLOCK_WOOD_COLLISION_SIZE;
            pBlock->m_bWallRun      = true;

            break;

        case TYPE_BENCH:

            pBlock->m_collisionSize = BLOCK_BENCH_COLLISION_SIZE;

            pBlock->m_bWallRun = true;
            //pBlock->m_bEnemyWallRan = true;

            break;

        case TYPE_TUKUE:

            pBlock->m_collisionSize = BLOCK_TUKUE_COLLISION_SIZE;

            pBlock->m_bWallRun = true;
            //pBlock->m_bEnemyWallRan = true;

            break;

        case TYPE_GUARDRAIL:

            pBlock->m_collisionSize = BLOCK_GUARDRAIL_COLLISION_SIZE;

            pBlock->m_bWallRun = true;
            //pBlock->m_bEnemyWallRan = true;

            break;

		case TYPE_PLAYGROUND:

			pBlock->m_collisionSize = BLOCK_PLAYGROUND_COLLISION_SIZE;
			pBlock->m_bWallRun = true;

			break;

		case TYPE_SIGN_EMAR:

			pBlock->m_collisionSize = BLOCK_SIGN_COLLISION_SIZE;

			break;

		case TYPE_SIGN_INTER:

			pBlock->m_collisionSize = BLOCK_SIGN_COLLISION_SIZE;

			break;

		case TYPE_SIGN_NO_PARK:

			pBlock->m_collisionSize = BLOCK_SIGN_COLLISION_SIZE;

			break;

		case TYPE_CAR:

			pBlock->m_collisionSize = BLOCK_CAR_COLLISION_SIZE;

			break;

		case TYPE_CONVINI:

			pBlock->m_collisionSize = BLOCK_CONVINI_COLLISION_SIZE;

			break;

		case TYPE_CONTAINER:

			pBlock->m_collisionSize = BLOCK_CONTAINER_COLLISION_SIZE;

			break;

		case TYPE_GAS:

			pBlock->m_collisionSize = BLOCK_GAS_COLLISION_SIZE;

			break;

		case TYPE_SOUKO:

			pBlock->m_collisionSize = BLOCK_SOUKO_COLLISION_SIZE;

			break;

		case TYPE_METAL:

			pBlock->m_collisionSize = BLOCK_METAL_COLLISION_SIZE;

			break;

		case TYPE_SOLAR:

			pBlock->m_collisionSize = BLOCK_SOLAR_COLLISION_SIZE;

			break;

		case TYPE_TOWER:

			pBlock->m_collisionSize = BLOCK_TOWER_COLLISION_SIZE;

			break;

		case TYPE_CRYSTAL:

			pBlock->m_collisionSize = BLOCK_CRYSTAL_COLLISION_SIZE;

			break;
    }

    return pBlock;
}
