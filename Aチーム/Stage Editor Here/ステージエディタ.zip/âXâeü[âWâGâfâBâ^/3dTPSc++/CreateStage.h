#ifndef CREATSTAGE_H
#define CREATSTAGE_H

#include "main.h"
#include "manager.h"
#include "input.h"
#include "scene.h"
#include "field.h"

#include <stdio.h>
#include <string.h>

#define BYTE (256)                                      // ������̊m�ۃ�������
#define BLOCK_SAVE_MAX_NUM (256)                        // �ύX���e��ۑ��o���鐔
#define OBJECT_MIN_NUM (1)                              // �I�u�W�F�N�g�̍Œᐔ
#define NEXT_DATA (1) // �����߂��ꍇ�́A�Q�Ƃ���z��
#define NEXT_TIME_DATA (2)
#define DEBUG_TXT_NAME "data/TXT/debug.txt"             // �ύX���e���o�͂���e�L�X�g�t�@�C��

class CCreateStage {
public:
	typedef enum {
		DETAILSCHANGE_NULL = 0,         // �ύX���e���ݒ�
		DETAILSCHANGE_CHANGE_POS,       // ���W�ύX
		DETAILSCHANGE_CHANGE_LAST_POS, // ���W�ύX(control + Z�𔻒�)
		DETAILSCHANGE_CHANGE_ROT,       // �����ύX
		DETAILSCHANGE_CHANGE_LAST_ROT, // �����ύX(control + Z�𔻒�)
		DETAILSCHANGE_BREAK,     // �I�u�W�F�N�g����
		DETAILSCHANGE_CREATE,    // �I�u�W�F�N�g����
		DETAILSCHANGE_TOTALELIMINATION, // �I�u�W�F�N�g�S����
		DETAILSCHANGE_MAX               // ���ڍő吔
	} DETAILSCHANGE;

	typedef enum {
		CREATEOBJECT_STAGE, // �X�e�[�W�ݒu���[�h
		CREATEOBJECT_ENEMY, // �G�ݒu���[�h
		CREATEOBJECT_MAX    // ���[�h�ő吔
	} CREATEOBJECT;

	typedef struct {
		int nNumber;                 // �ԍ�
		int nType;                   // ���
		bool bChangeJudge;           // �ύX��K�p����������
		DETAILSCHANGE DetailsChange; // �ύX���e
		D3DXVECTOR3 pos;             // ���W
		D3DXVECTOR3 rot;             // ����
		CScene::OBJTYPE ObjectType;  // �I�u�W�F�N�g�^�C�v
	}BLOCKSAVEDATE;

	CCreateStage();
	~CCreateStage();

	HRESULT Init(void);
	void Uninit(void);
	void Update(void);

	static HRESULT LoadStage(void);
	static HRESULT SaveStage(void);
	static HRESULT LoadEnemy(void);
	static HRESULT SaveEnemy(void);
	void CursorCollision(D3DXVECTOR3 pos, CREATEOBJECT m_CreateType);
	static CREATEOBJECT GetCreateObject(void) { return m_CreateType; }

	static bool GetFixedSshaft(int nshaft) { return m_bFixedSshaft[nshaft]; }
	static bool GetGreaseJudge(void) { return m_bGreaseJudge; }
	static bool GetSaveJudge(void) { return m_bSaveJudge; }
	static void SetSaveJudge(bool bJudge) { m_bSaveJudge = bJudge; }
	static bool GetPushedControlS(void) { return m_bPushedControlS; }
	static void SetPushedControlS(bool bJudge) { m_bPushedControlS = bJudge; }
	static D3DXVECTOR3 GetCopyPosR(void) { return m_CopyRot; }
	static D3DXVECTOR3 GetCopyPos(void) { return m_CopyPos; }
	static int GetCopynType(void) { return m_nCopyType; }
	static bool GetWriteSaveDetaJudge() { return m_WriteSaveDate; }
	static void SetWriteSaveDataJudge(bool bJudge) { m_WriteSaveDate = bJudge; }
	void CursorControl(D3DXVECTOR3 FixedSshaft, D3DXVECTOR3 CursorPos, CREATEOBJECT m_CreateType);
	void CreatBlockControl(D3DXVECTOR3 FixedSshaft, D3DXVECTOR3 CursorPos, D3DXVECTOR3 PosR, int nType, bool Judge, int nCount, CScene::OBJTYPE ObjectType, DETAILSCHANGE DetallsChange);
	void WriteBlockSaveDate(int nNumAll);
	int UndoingOperation(int nNumAll);
	int RedoUndoOperation(int nNumAll);
	int ShiftArray(int nCount);
	void SetCopyDate(D3DXVECTOR3 pos, D3DXVECTOR3 rot, int nType);
	void InitCopyDate(void);
	void SaveDate(D3DXVECTOR3 pos, D3DXVECTOR3 rot, int nNumber, DETAILSCHANGE DetailsChange, bool bChangeJudge, int nType, int nCount, CScene::OBJTYPE ObjectType);
	int BlockAllDelete(int nCount);
	int EnemyAllDelete(int nCount);
	int SetObject(CInputKeyboard* m_pInputKeyboard, D3DXVECTOR3 m_posR, CMouse* m_pMouse, int nCount, BLOCKSAVEDATE m_aBlockSaveDate, CREATEOBJECT m_CreateType);
	int SetEnemy(CInputKeyboard* m_pInputKeyboard, D3DXVECTOR3 m_posR, CMouse* m_pMouse, int nCount, BLOCKSAVEDATE m_aBlockSaveDate, CREATEOBJECT m_CreateType);
	void InitArray(int nCount);
	void CountDetallsChangeLAST(void);
	HRESULT LoadTextName(void);
	static char* GetTxtName(int nNumber) { return m_cTxtName[nNumber]; }

private:
	static D3DXVECTOR3 m_FieldSiz;
	D3DXVECTOR3 m_posR;
	D3DXVECTOR3 m_CursorPos;
	static D3DXVECTOR3 m_CopyRot;
	static D3DXVECTOR3 m_CopyPos;
	int m_nBlockType;
	int m_nEnemyType;
	static int m_nCopyType;
	CMouse* m_pMouse;
	CInputKeyboard* m_pInputKeyboard;
	static bool m_bFixedSshaft[2]; // 0->x��, 1->z��
	D3DXVECTOR3 m_FixedSshaft;
	static bool m_bGreaseJudge;
	static bool m_bSaveJudge;
	static bool m_bPushedControlS;
	static BLOCKSAVEDATE m_aBlockSaveDate[BLOCK_SAVE_MAX_NUM];
	static CREATEOBJECT m_CreateType;
	static bool m_bUseAllDelete;
	static bool m_WriteSaveDate;
	int m_nAllDeleteNum;                 // �S���������s�����u�Ԃ́A���̃I�u�W�F�N�g�̑���
	int m_nLastCountPos;
	int m_nLastCountRot;
	static char m_cTxtName[3][256];

	int nAddupAngle = 0;
	int nAddY = 0;
};

#endif
